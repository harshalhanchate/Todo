package org.TodoApp.org.TodoApp.Service;

import java.util.List;

import org.TodoApp.org.TodoApp.Entity.TodoEntity;

public interface TodoService {
	
	TodoEntity saveTodo(TodoEntity todo);

	List<TodoEntity> getAllTodos();

	TodoEntity getTodoById(int id);

	TodoEntity updateTodoById(TodoEntity todo, int id);

	TodoEntity updateCompleted(Boolean completed, int id);

	void deletedById(int id);

	Integer getCount();


}
