package org.TodoApp.org.TodoApp.Service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.TodoApp.org.TodoApp.Repository.TodoRepository;
import org.TodoApp.org.TodoApp.Entity.TodoEntity;

@Service
public class TodoServiceContract implements TodoService {

	@Autowired
	private  TodoRepository todoRepository;

	@Override
	public TodoEntity saveTodo(TodoEntity todo) {
		todo.setCreatedAt(new Date());
		todoRepository.save(todo);
		return todo;
	}

	@Override
	public List<TodoEntity> getAllTodos() {
		List<TodoEntity>  todos = todoRepository.findAll();
		return todos;
	}

	@Override
	public TodoEntity getTodoById(int id) {
		TodoEntity todo = todoRepository.findById(id).orElse(null);
		return todo;
	}

	@Override
	public TodoEntity updateTodoById(TodoEntity todo,int id) {
		TodoEntity updateTodo = todoRepository.findById(id).orElse(null);
		if(updateTodo!=null) {
		if(todo.getDescription()!=null) updateTodo.setDescription(todo.getDescription());
		if(todo.getTitle()!=null) updateTodo.setTitle(todo.getTitle());
		return todoRepository.save(updateTodo);
		}
		return null;
	}

	@Override
	public TodoEntity updateCompleted(Boolean completed, int id) {
		TodoEntity updateTodo = todoRepository.findById(id).orElse(null);
		if(updateTodo!=null) {
			updateTodo.setCompleted(completed);
			return todoRepository.save(updateTodo);
		}
		return updateTodo;
	}

	@Override
	public void deletedById(int id) {
		todoRepository.deleteById(id);
	
	
	}

	@Override
	public Integer getCount() {
		Integer count = (int) todoRepository.count();
		return count;
	}

	

}
