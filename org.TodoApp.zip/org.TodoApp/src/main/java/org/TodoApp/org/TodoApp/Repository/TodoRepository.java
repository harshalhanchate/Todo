package org.TodoApp.org.TodoApp.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import org.TodoApp.org.TodoApp.Entity.TodoEntity;

@Repository
public  interface TodoRepository extends JpaRepository<TodoEntity, Integer>{
	
	

}